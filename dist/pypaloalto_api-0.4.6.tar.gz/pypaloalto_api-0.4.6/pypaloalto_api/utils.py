import logging
import os
from requests.auth import AuthBase
import datetime
import xml.etree.ElementTree as ET

logging.basicConfig(format='%(asctime)s %(levelname)s: %(message)s', level=logging.INFO)


class ApiKeyAuth(AuthBase):
    """Implements a custom authentication scheme."""

    def __init__(self, _token):
        self.token = _token

    def __call__(self, r):
        """Attach an API token to a custom auth header."""
        r.headers['X-PAN-KEY'] = f'{self.token}'  # Python 3.6+
        return r


def read_file(full_file_name: str):
    with open(full_file_name, "r", encoding="UTF-8") as my_file:
        _value = my_file.read()

    return _value


def write_file(full_file_name: str, value: str):
    with open(full_file_name, "w", encoding="UTF-8") as my_file:
        my_file.write(value.strip())


def append_file(full_file_name: str, new_value: str, at_the_top=False):
    if not os.path.isfile(full_file_name):
        write_file(full_file_name, new_value.strip())

    else:
        _current_value = ""
        with open(full_file_name, "r", encoding="UTF-8") as my_file:
            _current_value = my_file.read()

        with open(full_file_name, "w", encoding="UTF-8") as my_file:
            if at_the_top:
                my_file.write(f"{new_value}{_current_value}".strip())
            else:
                my_file.write(f"{_current_value}{new_value}".strip())


def list_to_string(values_list: list, delimiter: str = " ") -> str:
    _result = ""

    for _item in values_list:
        _result += str(_item) + delimiter

    return _result[:len(_result) - len(delimiter)]


def get_current_date_time():
    return datetime.datetime.now().replace(microsecond=0).replace(tzinfo=None)


def get_current_date_time_as_string():
    return format_datetime_as_string(get_current_date_time())


def format_datetime_as_string(_datetime: datetime):
    return _datetime.strftime('%Y-%m-%d %H:%M:%S')


def format_datetime_as_string_ru(_datetime: datetime):
    return _datetime.strftime('%d-%m-%Y %H:%M:%S')


def format_date_as_string_ru(_datetime: datetime.date):
    return _datetime.strftime('%d-%m-%Y')


def parse_xml_to_json(xml: ET.Element, list_element_tags=[], empty_value=''):
    _result = {}

    for child in list(xml):
        if len(list(child)) > 0:
            _result[child.tag] = parse_xml_to_json(child, list_element_tags, empty_value)
        else:
            if child.tag in list_element_tags:
                if child.tag in _result:
                    _result[child.tag].append(child.text or empty_value)
                else:
                    _result[child.tag] = [child.text] if child.text else [empty_value]
            else:
                _result[child.tag] = child.text if child.text else empty_value

        # one-liner equivalent
        # response[child.tag] = parseXmlToJson(child) if len(list(child)) > 0 else child.text or ''

    return _result


def non_string_list_join(your_list: list, join_string: str):
    return join_string.join([str(x) for x in your_list])

# def parse_pa_json_to_pa_xml(json_obj):
#    result_list = list()
#
#    def parse(json_obj):
#        json_obj_type = type(json_obj)
#
#        if json_obj_type is list:
#            print(result_list)
#            if result_list[-1] != '<member>':
#                raise Exception(f'Unexpected key {result_list[-1]}\n{result_list}')
#
#            del result_list[-1]
#
#            for sub_elem in json_obj:
#                result_list.append(f'<member>{sub_elem}</member>')
#
#            return
#
#        if json_obj_type is dict:
#            for tag_name in json_obj:
#                sub_obj = json_obj[tag_name]
#                result_list.append(f'<{tag_name}>')
#                parse(sub_obj)
#
#                if tag_name != 'member':
#                    result_list.append(f'</{tag_name}>')
#
#            return
#
#        result_list.append(json_obj)
#        return
#
#    parse(json_obj)
#    return ''.join(result_list)
