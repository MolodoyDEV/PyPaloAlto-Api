import copy
import json
from enum import Enum
from abc import ABC
from pypaloalto_api import utils
from pypaloalto_api.enums import YesNo
import xml.etree.ElementTree as ET
import dicttoxml


class CompositeType(ABC):
    pass


class ProfileSettings:
    pass


class NoneProfileSettings(ProfileSettings):
    pass


class Profiles(ProfileSettings):
    pass


class Groups(ProfileSettings):
    pass


class NoneTargetDeviceEntry:
    pass


class TargetDeviceEntry(CompositeType):

    def __init__(self, _serial: str, _vsys=[]):
        self.serial = _serial

        if not isinstance(_vsys, list):
            raise TypeError("Expected list vsys!")

        self.vsys = _vsys

        self.json = {'@name': self.serial}
        if self.vsys != []:
            self.json['vsys'] = {'entry': []}
            _entry = self.json['vsys']['entry']

            for _v in self.vsys:
                _entry.append({'@name': _v})

    def get_json(self):
        return self.json


class RuleAction(Enum):
    allow = 'allow'
    deny = 'deny'
    drop = 'drop'
    reset_client = 'reset-client'
    reset_server = 'reset-server'
    reset_both = 'reset-both'


class RuleKey(Enum):
    from_zone_list = 'from/member'
    to_zone_list = 'to/member'
    source_list = 'source/member'
    source_user_list = 'source-user/member'
    destination_list = 'destination/member'
    service_list = 'service/member'
    application_list = 'application/member'
    disabled = 'disabled'
    action = 'action'
    tag_root = 'tag'
    tag_list = 'tag/member'
    group_tag = 'group-tag'
    schedule = 'schedule'
    description = 'description'
    log_setting = 'log-setting'
    profile_setting = 'profile-setting'
    profile_setting_profiles = 'profile-setting/profiles'
    profile_setting_profiles_file_blocking = 'profile-setting/profiles/file-blocking'
    profile_setting_profiles_virus = 'profile-setting/profiles/virus'
    profile_setting_profiles_spyware = 'profile-setting/profiles/spyware'
    profile_setting_profiles_vulnerability = 'profile-setting/profiles/vulnerability'
    profile_setting_profiles_wildfire_analysis = 'profile-setting/profiles/wildfire-analysis'
    profile_setting_profiles_url_filtering = 'profile-setting/profiles/url-filtering'
    profile_setting_profiles_data_filtering = 'profile-setting/profiles/data-filtering'
    profile_setting_group = 'profile-setting/group/member'
    negate_destination = 'negate-destination'
    negate_source = 'negate-source'
    rule_name = '@name'
    log_start = 'log-start'
    log_end = 'log-end'
    target_tags = 'target/tags'
    target_tags_list = 'target/tags/member'
    target_devices = 'target/devices'
    target_devices_list = 'target/devices/entry'
    target_negate = 'target/negate'


DEFAULT_VALUES_BY_KEY = {
    RuleKey.from_zone_list: ['any'],
    RuleKey.to_zone_list: ['any'],
    RuleKey.source_list: ['any'],
    RuleKey.source_user_list: ['any'],
    RuleKey.destination_list: ['any'],
    RuleKey.service_list: ['any'],
    RuleKey.application_list: ['any'],
    RuleKey.disabled: YesNo.no,
    RuleKey.negate_destination: YesNo.no,
    RuleKey.negate_source: YesNo.no,
    RuleKey.log_start: YesNo.no,
    RuleKey.log_end: YesNo.yes,
    RuleKey.action: RuleAction.allow,
    RuleKey.tag_root: {},
    RuleKey.tag_list: [],
    RuleKey.group_tag: '',
    RuleKey.schedule: '',
    RuleKey.description: '',
    RuleKey.log_setting: '',
    RuleKey.target_tags_list: ['any'],
    RuleKey.target_devices_list: ['any'],
    RuleKey.target_negate: YesNo.no,
    RuleKey.profile_setting_profiles_file_blocking: [],
    RuleKey.profile_setting_profiles_virus: [],
    RuleKey.profile_setting_profiles_spyware: [],
    RuleKey.profile_setting_profiles_vulnerability: [],
    RuleKey.profile_setting_profiles_wildfire_analysis: [],
    RuleKey.profile_setting_profiles_url_filtering: [],
    RuleKey.profile_setting_profiles_data_filtering: []
}

NONE_CLASSES = (NoneProfileSettings, NoneTargetDeviceEntry)


class SecurityRule:
    __is_modified = False

    def __init__(self, rule):
        rule = copy.deepcopy(rule)

        if isinstance(rule, dict):
            self.__uuid = rule.pop('@uuid', None)
            self.__real_location = rule.pop('@loc', None)
            self.__rule = rule
        elif isinstance(rule, ET.Element):
            if rule.tag == 'entry':
                _entry = rule
            else:
                _entry = rule.find('.//entry')

            _rule_name = _entry.get('name')
            self.__rule = utils.parse_xml_to_json(_entry, list_element_tags=['member'])
            self.__rule['@name'] = _rule_name
        else:
            raise TypeError(
                f"This class supports initializing only from dict and xml-element types! {type(rule)} was given")

    @property
    def is_modified(self) -> bool:
        return self.__is_modified

    @property
    def name(self):
        return self.__rule['@name']

    @property
    def device_group(self):
        return self.__rule['@device-group'] if self.__rule["@location"] == 'device-group' else 'shared'

    def _has_key(self, key: RuleKey):
        _key_chain = key.value.split('/')
        _value = self.__rule

        for _i in _key_chain:
            if _i in _value:
                _value = _value[_i]
            else:
                return False

        return True

    def get_value(self, key: RuleKey):
        _key_chain = key.value.split('/')
        _value = self.__rule

        for _i in _key_chain:
            if _i in _value:
                _value = _value[_i]
            else:
                return DEFAULT_VALUES_BY_KEY[key]

        return _value

    def append_value(self, key: RuleKey, addition_value: list):
        if not isinstance(DEFAULT_VALUES_BY_KEY[key], list):
            raise TypeError("Only list value can be extended")

        _key_chain = key.value.split('/')
        _target_key = _key_chain[len(_key_chain) - 1]
        _json = self.__rule

        for _i in _key_chain:
            if _i in _json:
                _json = _json[_i]
            else:
                break

        if len(addition_value) != 0:
            _new_value = list(set(self.get_value(key) + addition_value))
            self.try_set_value_if_diff(key, _new_value)

    def try_delete_key(self, key: RuleKey):
        _key_chain = key.value.split('/')
        _last_key = _key_chain[-1]
        _json = self.__rule

        for _k in _key_chain:
            if _k in _json:
                if _k != _last_key:
                    _json = _json[_k]
            else:
                return False

        _json.pop(_last_key)
        self.__is_modified = True
        return False

    def try_set_value_if_diff(self, key: RuleKey, value):
        # Returns None if key was deleted
        value = self.__prepare_value_to_set(key, value)

        if value:
            _is_settled = self.__set_value_if_diff(key, value)

            if _is_settled:
                if RuleKey.profile_setting_group.value in key.value:
                    self.try_delete_key(RuleKey.profile_setting_profiles)

                elif RuleKey.profile_setting_profiles.value in key.value:
                    self.try_delete_key(RuleKey.profile_setting_group)

                elif RuleKey.target_tags.value in key.value:
                    self.try_delete_key(RuleKey.target_devices)

                elif RuleKey.target_devices.value in key.value:
                    self.try_delete_key(RuleKey.target_tags)

            return _is_settled
        else:
            return True

    def __prepare_value_to_set(self, key: RuleKey, value):
        if key == RuleKey.rule_name:
            raise Exception("Rule name can't be settled!")

        if issubclass(type(value), Enum):
            value = value.value

        elif isinstance(value, list):
            if value == list():
                if key == RuleKey.tag_list:
                    self.try_delete_key(RuleKey.tag_root)
                    return None
                else:
                    # value = ['any']
                    value = []

            else:
                if value != ['any'] and 'any' in value:
                    value.remove('any')

                if isinstance(value[0], TargetDeviceEntry):
                    _new_value = []

                    for _v in value:
                        _new_value.append(_v.get_json())

                    value = _new_value

        elif issubclass(value.__class__, CompositeType):
            value = value.get_json()

        return value
        # self.__set_value_if_diff(_key, _value)

    def __set_value_if_diff(self, rule_key: RuleKey, value):
        _key_chain = rule_key.value.split('/')
        _last_key = _key_chain[-1]
        _json = self.__rule

        for _key in _key_chain:
            # Если ключ является последним в цепочки искомых ключей, то пытаемся присвоить ему пользовательское значение
            if _key == _last_key:
                if _key not in _json:
                    _json[_key] = value
                    self.__is_modified = True

                elif isinstance(value, list):
                    if set(_json[_key]) != set(value):
                        _json[_key] = value
                        self.__is_modified = True

                elif _json[_key] != value:
                    _json[_key] = value
                    self.__is_modified = True

                return True

            # Если ключ есть в джейсоне, то получаем его значение для последующих итераций
            elif _key in _json:
                _json = _json[_key]

            # Если какого-то промежуточного ключа нет в json, То добавляем всю последовательность ключей после него.
            else:
                _index_of_current_key = _key_chain.index(_key)
                _missed_keys = _key_chain[_index_of_current_key::]
                _count = 0

                while _count < len(_missed_keys) - 1:
                    _json[_missed_keys[_count]] = {_missed_keys[_count + 1]: None}
                    _json = _json[_missed_keys[_count]]
                    _count += 1

                _json[_missed_keys[_count]] = value
                self.__is_modified = True
                return True

        return False

    def clear_is_modified_flag(self):
        self.__is_modified = False

    def to_dict(self) -> dict:
        return copy.deepcopy(self.__rule)

    def to_xml(self) -> ET.Element:
        _temp_dict = self.to_dict()

        _temp_dict.pop('@device-group', '')
        _rule_name = _temp_dict['@name']
        _temp_dict.pop('@name', '')
        _temp_dict.pop('@location', '')

        def remove_member_key_from_dict(_dict: dict):
            for _key, _value in _dict.items():
                if isinstance(_value, dict):
                    _dict[_key] = remove_member_key_from_dict(_value)
                elif _key == 'member':
                    return _value

            return _dict

        _temp_dict = remove_member_key_from_dict(_temp_dict)
        _xml = dicttoxml.dicttoxml(_temp_dict, attr_type=False, custom_root='entry', item_func=lambda x: 'member')
        _xml = ET.fromstring(_xml)
        _xml.set('name', _rule_name)

        return _xml

    def __repr__(self):
        return str(self.__rule)


class SecurityRulesBuilder:
    @staticmethod
    def create_security_rules_list(rules) -> list:
        """Takes json or xml reply from PaloAlto device
        Returns list of SecurityRules"""
        _rules_list = []

        if isinstance(rules, list):
            pass

        elif isinstance(rules, ET.Element):
            rules = rules.findall('.//entry')

        else:
            raise TypeError("This class supports initializing only from dict and xml-element types!")

        for _rule in rules:
            _rules_list.append(SecurityRule(_rule))

        return _rules_list

    @staticmethod
    def security_rule_from_json(json_string: str):
        """Takes json as string
        Return an instance SecurityRule"""

        return SecurityRule(json.loads(json_string))

    @staticmethod
    def security_rule_from_dict(rule_as_dict: dict):
        """Takes a dict object
        Return an instance SecurityRule"""

        return SecurityRule(rule_as_dict)

    @staticmethod
    def security_rule_from_xml(rule_as_xml: ET.Element):
        """Takes a XML-Element object
        Return an instance SecurityRule"""

        return SecurityRule(rule_as_xml)

    @staticmethod
    def security_rule_from_arguments(rule_key_value_pairs: dict):
        """Takes dict like {RuleKeys.rule_name: 'test_name', RuleKeys.....}
        Return an instance SecurityRule"""

        if RuleKey.rule_name not in rule_key_value_pairs:
            raise Exception('RuleKeys.name must be in rule_key_value dict!')

        _security_rule = SecurityRule({'@name': rule_key_value_pairs.pop(RuleKey.rule_name)})

        for _key in RuleKey:
            if _key in rule_key_value_pairs:
                _security_rule.try_set_value_if_diff(_key, rule_key_value_pairs[_key])

            elif _key in DEFAULT_VALUES_BY_KEY:
                _security_rule.try_set_value_if_diff(_key, DEFAULT_VALUES_BY_KEY[_key])

        _all_keys_as_string = ','.join([x.value for x in rule_key_value_pairs])

        if RuleKey.profile_setting_group.value in _all_keys_as_string:
            _security_rule.try_delete_key(RuleKey.profile_setting_profiles)

        elif RuleKey.profile_setting_profiles.value in _all_keys_as_string:
            _security_rule.try_delete_key(RuleKey.profile_setting_group)

        return _security_rule
