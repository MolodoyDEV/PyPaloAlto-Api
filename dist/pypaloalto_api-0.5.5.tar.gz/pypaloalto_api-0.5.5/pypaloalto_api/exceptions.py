import json


class PaloAltoException(Exception):
    pass


class PaloAltoApiRequestException(PaloAltoException):
    def __init__(self, status_code: int = 0, content: str = '', description: str = ''):
        self.status_code = status_code
        self.content = content
        self.description = description

    @property
    def json(self) -> dict:
        try:
            return json.loads(self.content)
        except:
            return {}
